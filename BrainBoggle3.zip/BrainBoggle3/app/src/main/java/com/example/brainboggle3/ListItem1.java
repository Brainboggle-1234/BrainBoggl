package com.example.brainboggle3;

public class ListItem1
{
    private String quiz;


    public ListItem1(String quiz)
    {
        this.quiz=quiz;



    }
    public String getQuiz()
    {
        return quiz;
    }
}
