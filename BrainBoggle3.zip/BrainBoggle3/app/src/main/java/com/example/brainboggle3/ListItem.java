package com.example.brainboggle3;

public class ListItem
{
    private String course;


    public ListItem(String course)
    {
        this.course=course;


    }
    public String getCourse()
    {
        return course;
    }

}
